AstroTour KZ — Atlas Edition · 6 pages · ҚАЗ / ENG

1. Extract the ZIP fully before opening the site.
2. Open index.html in a browser. Do not open from inside WinRAR.
3. Kazakh is default, English is optional; Russian has been removed.
4. The interactive sky atlas includes 9 illustrated constellations and 3 star-density modes (240, 520, 780 stars).
5. Navigation: index, places, map, sky, planner, guide.
6. Language choice, favorites, packing checklist and star density are saved locally.
7. Sky diagrams are educational illustrations, not a real-time sky-position service; Moon illumination is approximate.
8. Images and web fonts may require an internet connection. No server, booking, payment, or live forecast is included.
